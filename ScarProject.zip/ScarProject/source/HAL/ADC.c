/*
 * ADC.c
 *
 *  Created on: 18 ago. 2020
 *      Author: user
 */
#include "ADC.h"
void vfnADCDriverInit(void) {




	        SIM->SCGC6|= SIM_SCGC6_ADC0_MASK;
	    	ADC0->CFG1|= ADC_CFG1_MODE(3);//16 bit resolution
	       ADC0-> SC2|= ADC_SC2_REFSEL_MASK;

	}
uint_16 bfnReturnADC(uint_8 bChannel){
	 ADC0->SC1[0]=bChannel;

    		while(ADC0->SC1[0] != (ADC_SC1_COCO_MASK | bChannel) );
    		return ADC0->R[0];

}

