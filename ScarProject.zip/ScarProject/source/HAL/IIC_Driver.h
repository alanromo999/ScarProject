/*
 * IIC_Driver.h
 *
 *  Created on: 20 jul. 2020
 *      Author: user
 */

#ifndef HAL_IIC_DRIVER_H_
#define HAL_IIC_DRIVER_H_
#define         I2C_BAUD        9600 ///<I2C baudrate
#define         SSD1306ADD      0x3C ///<Address of ssd1306
#define        I2C_READ           0 ///<Read mode
#define       I2C_WRITE           1 ///<Write mode
#include "MyTypes.h"
/**
 * Wait to writte data
 */
void vfnI2C_Waitto(void);
/**
 * Wait to ACK
 */
void vfnWhileAckR(void);
/**
 * Calculates de bitrate of I2C
 * lSaveBitrate=clk/((mult)*vIcrValue);
 * @point[in] bpmult
 * @param[in] bpicr
 * @param[in] bCommbr
 */
void  I2C_bfnDriverBitRate(uint_8 *bpmult, uint_8 *bpicr, uint_32 bCommbr);
/**
 * Driver init I2C
 */
void I2C_bfnDriverInit(void);
/**
 * Send data via I2C
 * @point[in] bTxData
 * @param[out] bStatus
 */
uint_8 I2C_bfnSend(uint_8 bTxData);
/**
 * read data via I2C
 * @point[in] bTxData
 * @param[out] bStatus
 */
uint_8 I2C_bfnRead(uint_8 *bpRxData);
/**
 * Clock init
 */
void Clock_Init(void);
/**
 * releasesBus I2C
 */
void I2C_ReleaseBus(void);
/**
 * Delay
 */
void I2C_Delay(void);
/**
 *Send start
 */
void vfnStartI2C(void);
/**
 *Return icr value of icr position
 *param[in]vPosition
 *param[out]vaIcrScl[vPosition]
 */
uint_16 vfnReturnIcr(uint_8 vPosition);

#endif /* HAL_IIC_DRIVER_H_ */
