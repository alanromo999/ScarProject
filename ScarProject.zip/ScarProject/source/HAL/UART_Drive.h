/*
 * INICIA.H
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#ifndef HALL_INICIA_H_
#define HALL_INICIA_H_
#include <MyTypes.h>
#define			UART_BAUDRATE 	9600 ///< bAUDRATE UART
#define 		IR 				8000000 ///< IR UART
#define			SBR				(IR/((15+1)*(UART_BAUDRATE))) ///< BAUDRATE FORMULA
/**
 *UART Driver Init
 */

void UART_vfnDriverInit (void);
/**

 *Read UART Value

 * @param[in] bpRxData

 * @param[out] bStatus

*/
uint_8 UART_bfnRead (uint_8 *bpRxData);
/**

 *Send UART Value

 * @param[in] bpRxData

 * @param[out] bStatus

*/
uint_8 UART_bfnSend (uint_8 bTxData);




#endif /* HALL_INICIA_H_ */
