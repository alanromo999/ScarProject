#include <HAL/IIC_Driver.h>
static volatile uint_8 ACKReceived = FALSE;

void I2C_bfnDriverInit(void){
uint_8 vMult=0;
uint_8 vIcr=0;
//llamar CLOCK DRIVER INIT
    Clock_Init();
	I2C_ReleaseBus();
    SIM -> SCGC4 |= SIM_SCGC4_I2C0_MASK;
    I2C0->A1 = 0;
    I2C0->F  = 0;
    I2C0->C1 = 0;
    I2C0->S  = 0xFFU;
    I2C0->C2 = 0;
    I2C0->FLT = 0x50;
    I2C0->RA = 0;
    SIM -> SCGC5 |= SIM_SCGC5_PORTE_MASK;
    PORTE -> PCR[24]|= (PORT_PCR_PE(1)|PORT_PCR_PS(1)|PORT_PCR_MUX(5)); // SCL
    PORTE -> PCR[25]|= (PORT_PCR_PE(1)|PORT_PCR_PS(1)|PORT_PCR_MUX(5)); // SDA
    I2C_bfnDriverBitRate(&vMult, &vIcr,I2C_BAUD);
    I2C0 -> F = (I2C_F_MULT(vMult)|I2C_F_ICR (vIcr));
    I2C0->FLT = 0;
    NVIC->ISER[0] |= (1 << I2C0_IRQn);
    I2C0 -> C1 |=I2C_C1_IICIE(1);
    I2C0 -> C1 |=I2C_C1_IICEN(1);


}
void vfnStartI2C(void){
 uint_8 bdirection;
 	if(!(I2C0->S & I2C_S_BUSY_MASK)){
 		bdirection= I2C_WRITE;
 		I2C0->C1 |= I2C_C1_MST_MASK | I2C_C1_TX_MASK;
 		vfnI2C_Waitto();
 		I2C0->D=(uint_8 )((((uint_32)SSD1306ADD)<<1)| ((bdirection==I2C_READ)? 1 :0));

 	}
 	vfnWhileAckR();

}
void vfnI2C_Waitto(void){
	while((I2C0->S2 & I2C_S2_EMPTY_MASK)==0U)//WAIT TO WRITE
			{
			}
}


void vfnWhileAckR(void){
	  while(ACKReceived == FALSE){
	        }
	        ACKReceived = FALSE;
}

uint_8 I2C_bfnRead(uint_8 *bpRxData)
	{
	    uint_8 bStatus=0;
	        if(!(I2C_S_RXAK_MASK & I2C0 ->S)){//recive ak
	        	bStatus=SUCCESS;
			    vfnI2C_Waitto();
			    *bpRxData= I2C0 ->D ;
	        }else{
	        	bStatus=ERROR;
	        }
	return bStatus;
	}


uint_8 I2C_bfnSend(uint_8 bTxData){
	uint_8 bStatus=0;
      if(I2C_S2_EMPTY_MASK & I2C0 ->S2){//recive ak
		    bStatus=SUCCESS;
		    vfnI2C_Waitto();
		    I2C0 ->D = bTxData ;
		    vfnWhileAckR();
            }else{
		     bStatus=ERROR;
		    }
		return bStatus;
}
void I2C0_DriverIRQHandler (void){
    I2C0->S |= I2C_S_IICIF_MASK;
    if(!(I2C0->S & I2C_S_RXAK_MASK)){
        ACKReceived = TRUE;
    }

}

uint_16 vfnReturnIcr(uint_8 vPosition){
    uint_16 vaIcrScl[64]={20,22,24,26,28,30,34,40,28,32,36,40,44,48,56,68,48,56,//18
                        64,72,80,88,104,128,80,96,112,128,144,160,192,240,160,//15
                        192,224,256,288,320,384,480,320,384,448,512,576,640,//13
                        768,960,640,768,896,1024,1152,1280,1536,1920,1280,//11
                        1536,1792,2048,2304,2560,3072,3840};//7
                        return vaIcrScl[vPosition];
}

void  I2C_bfnDriverBitRate(uint_8 *bpmult, uint_8 *bpicr, uint_32 bCommbr)
{
	//mult 0 1 2 3
     //scl diver 0 63
	//mux 0-3
/* i2c baudrate = i2c module clock spped / ((mux) x scl divider)  scl divider va de 0 a 63 */
	uint_32 lSaveBitrate = 0xFFFFFFFF;// recibira el resultado del bitrate
	uint_32 lSaveDiffe = 0xFFFFFFFF; //  diferencia entre valores
	uint_32 lBestDiffe = 0xFFFFFFFF; // la mejor diferencia
	uint_8 lBestbpmult = 0XFF;
	uint_8 lBesticr = 0XFF;
	uint_8 bBitRateMatch = ERROR;
	uint_16 vIcrValue=0xFFFF;
	for(uint_8 multCont= 1; multCont <= 4; ){
    	for(uint_8 icrCont =0; icrCont <=63 ; icrCont++){
    		vIcrValue=vfnReturnIcr(icrCont);
    		lSaveBitrate=48000000/((multCont)*vIcrValue);
    		lSaveDiffe = (bCommbr > lSaveBitrate) ? bCommbr - lSaveBitrate : lSaveBitrate - bCommbr; //10
    		    		if(bCommbr == lSaveBitrate){
    		    			*bpmult = multCont;
    		    			*bpicr = icrCont;
    		    			bBitRateMatch =  SUCCESS;
    		    		}
    		    			else if (lSaveDiffe < lBestDiffe){
    		    				lBestDiffe = lSaveDiffe;
    		    				lBestbpmult =  multCont;
    		    				lBesticr =  icrCont;
    		    			}
    		    	}
    	            multCont=multCont+multCont;
    		    }

    		    if(bBitRateMatch == ERROR){
    		    	*bpmult = lBestbpmult;
    		    	*bpicr = lBesticr;
    		    }
    		    switch (*bpmult){
				case 1:
				*bpmult=0;
				break;
				case 2:
				*bpmult=1;
				break;
				case 4:
				*bpmult=2;
				break;
				default:
				*bpmult=0xF;
				break;
    		    }
}

void Clock_Init(void){
    SIM->CLKDIV1 = 0x10030000U; // configuration to have the 48MHz clock {
    MCG->SC = MCG_SC_FCRDIV(0);
    MCG -> MC = MCG_MC_HIRCEN(1) | MCG_MC_LIRC_DIV2(0);
    MCG -> C2 = (MCG-> C2 & ~MCG_C2_IRCS_MASK) | MCG_C2_IRCS(1);
    MCG -> C1 = MCG_C1_CLKS(0) | 2;



    while (0 != ((MCG->S & MCG_S_CLKST_MASK)>>MCG_S_CLKST_SHIFT))
    {
    }
    SIM->CLKDIV1 = 0x10000;
    SIM->SOPT1 = ((SIM->SOPT1 & ~SIM_SOPT1_OSC32KSEL_MASK)|SIM_SOPT1_OSC32KSEL(0)); //}
}
void I2C_ReleaseBus(void){
    //function performed by a delivery bus for the OLED
    SIM->SCGC5 |= SIM_SCGC5_PORTE(1);
    PORTE->PCR[25] = PORT_PCR_PE(1)|PORT_PCR_PS(1)|PORT_PCR_MUX(1);
    PORTE->PCR[24] = PORT_PCR_PE(1)|PORT_PCR_PS(1)|PORT_PCR_MUX(1);
    GPIOE->PDDR |= 1<<24;
    GPIOE->PDOR |= 1<<24;
    GPIOE->PDDR |= 1<<25;   //Initialization of the E24 and 25 ports as GPIO and activate them as pullup resistors
    GPIOE->PDOR |= 1<<25;



    GPIOE->PDOR &=~ (1<<25);

    I2C_Delay();



    GPIOE->PDOR &=~ (1<<24);
    I2C_Delay();



    GPIOE->PDOR |= (1<<25);
    I2C_Delay();
                                        //Release bus for the OLED with a delay of plus or minus 10us
    GPIOE->PDOR |= (1<<24);
    I2C_Delay();
    GPIOE->PDOR &=~ (1<<24);
    I2C_Delay();



    GPIOE->PDOR &=~ (1<<25);
    I2C_Delay();



    GPIOE->PDOR |= (1<<24);
    I2C_Delay();



    GPIOE->PDOR |= (1<<25);
    I2C_Delay();



}
void I2C_Delay(void){
    uint_32 i;

    for(i=0;i<100;i++){
        __NOP();        //NOP operation takes 1 us to perform

    }
}
