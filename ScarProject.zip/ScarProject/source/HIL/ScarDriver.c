/*
 * ScarDriver.c
 *
 *  Created on: 21 ago. 2020
 *      Author: user
 */

#include "ScarDriver.h"
#include "OLED.h"
#include "PWMDriver.h"
#include "BTDriver.h"
#include "ADC.h"
#include "GPIO.h"


void vfnReadScarDataBT(void){
	uint_8 bValueToR=0xFF;
	static volatile uint_16 bSpeed=1500;
	static volatile uint_8 bCount=1;
	static volatile uint_16 bCheckBatterry=0;
#ifdef SSDEXTERN
	if(bCheckBatterry==50000){
		vfnsSSD1306CBat();
		bCheckBatterry=0;

	}
#endif
	if(UART_bfnRead (&bValueToR)){
#ifdef SSDEXTERN
		if(bCount){
		vfnPaired();
		vfnsSSD1306CBat();
		bCount--;
		}
#endif
		switch(bValueToR){
		case 'P':
	    vfnStopPWM();
	    bCheckBatterry++;
		break;
		case 'F'://MOVE FORWARD
		vfnMoveFordward(bSpeed);
		 bCheckBatterry++;
		bValueToR='P';
		break;
		case 'B'://MOVE BACK
		vfnMoveBack(bSpeed);
		 bCheckBatterry++;
		bValueToR='P';
		break;
		case 'L'://MOVE LEFT
		vfnMoveLeft(bSpeed);
		 bCheckBatterry++;
		bValueToR='P';
		break;
		case 'R'://MOVE RIGHT
		vfnMoveRight(bSpeed);
		 bCheckBatterry++;
		bValueToR='P';
		break;
		case 'G'://MOVE FORWARD-LEFT
		vfnMoveFordAndLeft(bSpeed);
		 bCheckBatterry++;
		bValueToR='P';
		break;
	    case 'I'://MOVE FORWARD-RIGHT
	    vfnMoveFordAndRight(bSpeed);
	    bCheckBatterry++;
	    bValueToR='P';
	    break;
		case 'H'://MOVE BACK-LEFT
	    vfnMoveBackAndLeft(bSpeed);
	    bCheckBatterry++;
		bValueToR='P';
		break;
	    case 'J'://MOVE BACK-RIGHT
		vfnMoveBackAndRight(bSpeed);
		 bCheckBatterry++;
	    bValueToR='P';
		break;
		case 'S'://MOVE STOP
		vfnStopPWM();
		 bCheckBatterry++;
		break;
		case 'W'://FRONT LIGHTS ON
			vfnLedTurnFOn();
			 bCheckBatterry++;
			break;
		case 'w'://FRONT LIGHTS OFF
			vfnLedTurnFOff();
			 bCheckBatterry++;
			break;
	case 'U'://FRONT LIGHTS ON
		vfnLedTurnBOn();
		 bCheckBatterry++;
		    break;
	case 'u'://FRONT LIGHTS OFF
		vfnLedTurnBOff();
		 bCheckBatterry++;
		    break;
		case '0':
			bSpeed=1500;
			 bCheckBatterry++;
		    break;
		case '1':
			bSpeed=2350;
			 bCheckBatterry++;
		    break;
	case '2':
			bSpeed=3200;
			 bCheckBatterry++;
		    break;
		case '3':
			bSpeed=4050;
			 bCheckBatterry++;
			break;
		case '4':
			bSpeed=4900;
			 bCheckBatterry++;
			break;
		case '5':
			bSpeed=5750;
			 bCheckBatterry++;
			break;
		case '6':
			bSpeed=6600;
			 bCheckBatterry++;
			break;
		case '7':
			bSpeed=7450;
			 bCheckBatterry++;
			break;
		case '8':
			bSpeed=8300;
			 bCheckBatterry++;
		break;
		case '9':
			bSpeed=9150;
			 bCheckBatterry++;
			break;
		case 'q'://MOVE SPEED 10
			bSpeed=10000;
			 bCheckBatterry++;
			break;
		case 'D'://STOP ALL
			bSpeed=0;
			 bCheckBatterry++;

			break;
	    default:
			break;
		}
		}

	}
