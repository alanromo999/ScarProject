/*
 * LedDriver.c
 *
 *  Created on: 23 ago. 2020
 *      Author: user
 */

#include <GPIO.h>
void vfnGPIODriverInit(void){


	PORTA-> PCR[2] |= PORT_PCR_MUX(1);//FRONT
	PORTA-> PCR[1] |= PORT_PCR_MUX(1);//BACK
    GPIOA->PDDR |= (1<<1);
    GPIOA->PDDR |= (1<<2);
}
void vfnLedTurnFOn(void){
	GPIOA -> PDOR |= (1<<1);//FRONT

}
void vfnLedTurnFOff(void){
	GPIOA -> PDOR &= ~ (1<<1);//FRONT
}
void vfnLedTurnBOn(void){
	GPIOA -> PDOR |= (1<<2);//FRONT
}
void vfnLedTurnBOff(void){
	GPIOA -> PDOR &= ~ (1<<2);
}

