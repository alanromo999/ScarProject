/*
 * ADC.h
 *
 *  Created on: 18 ago. 2020
 *      Author: user
 */

#ifndef HIL_ADC_H_
#define HIL_ADC_H_
#include "MyTypes.h"
/**
 * Init of ADC
 */
void vfnADCDriverInit(void);
/**
 * Return the value of the channel selected
 * @param[in] bChannel
 * @param[out] ADC0->R[0]
 */
uint_16 bfnReturnADC(uint_8 bChannel);


#endif /* HIL_ADC_H_ */
