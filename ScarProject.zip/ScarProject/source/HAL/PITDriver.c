/*
 * PITDriver.c
 *
 *  Created on: 22 ago. 2020
 *      Author: user
 */
#include "PITDriver.h"

void (*vfnCallBack)(void)=NULL;
void vfnPITCallBackreg(void *(vfncall)(void)){
	vfnCallBack=vfncall;
}

void vfnPITDriverInit(void){
	SIM->SCGC6 |= SIM_SCGC6_PIT_MASK;
	PIT->MCR &= ~(PIT_MCR_FRZ_MASK);
	PIT->MCR &= ~(PIT_MCR_MDIS_MASK);
	PIT-> CHANNEL[0].LDVAL|=900000000000000000000;
	//0x66689E

	PIT-> CHANNEL[0].TCTRL|=PIT_TCTRL_TIE_MASK;
	NVIC->ISER[0] |= (1 << PIT_IRQn);

}
void vfnPITEnable(void){
	PIT-> CHANNEL[0].TCTRL|=PIT_TCTRL_TEN_MASK;
}
void vfnPITDisable(void){
	PIT-> CHANNEL[0].TCTRL&= ~(PIT_TCTRL_TEN_MASK);
}
void PIT_IRQ(void){
	if(vfnCallBack != NULL){
		(*vfnCallBack)();
	}else{
	}
	PIT-> CHANNEL[0].TFLG |= (1<<31) ;
}
uint_8 bfnPITCheckFlag(void){
	uint_8 bStatus=0;
	if(PIT-> CHANNEL[0].TFLG){
		bStatus=1;
		PIT-> CHANNEL[0].TFLG |= (1<<31) ;
	}else{
		bStatus=0;
	}
return bStatus;
}
