
#include "PWMDriver.h"
void vfPWMDriverInit (void){


	SIM->SCGC5 |= SIM_SCGC5_PORTD(1);
	SIM->SCGC5 |= SIM_SCGC5_PORTA(1);
	SIM->SCGC6 |= SIM_SCGC6_TPM0(1);			//Clock enabled
	SIM->SOPT2 |= SIM_SOPT2_TPMSRC(3);		//MCGIRCLK clock

	PORTD->PCR[0] |= PORT_PCR_MUX(4);			//PIN 24 PUERTO E ALTERNATIVA 3 TPM0_CH0
	PORTD->PCR[1] |= PORT_PCR_MUX(4);			//PIN 25 PUERTO E ALTERNATIVA 3 TPM0_CH1
	PORTD->PCR[2]  |= PORT_PCR_MUX(4);			//PIN 5 PUERTO A ALTERNATIVA 3 TPM0_CH2
	PORTD->PCR[3] |= PORT_PCR_MUX(4);			//PIN 25 PUERTO E ALTERNATIVA 3 TPM0_CH4

	TPM0->SC |= TPM_SC_PS(4);					//0b111..Divide by 128
	TPM0->SC |= TPM_SC_CPWMS(1);				//TPM counter operates in up-down counting mode.
	TPM0->MOD = 10000;
	TPM0->CONF |= TPM_CONF_DBGMODE(3);			//0b11 TPM counter continues in debug mode.
	TPM0->SC |= TPM_SC_CMOD(1);				//0b01..TPM counter increments on every TPM counter clock

	TPM0->CONTROLS[0].CnSC |= 0x28;	//(1<<TPM_CnSC_MSB_SHIFT);
	TPM0->CONTROLS[1].CnSC |= 0x28;	//(1<<TPM_CnSC_MSB_SHIFT);
	TPM0->CONTROLS[2].CnSC |= 0x28;	//(1<<TPM_CnSC_MSB_SHIFT);
	TPM0->CONTROLS[3].CnSC |= 0x28;	//(1<<TPM_CnSC_MSB_SHIFT)

}

//PORTD0-CH0-RTB
////PORTD1-CH1-LSB
//PORTD2-CH2-RTF
//PORTD3-CH3-LTF
void vfnMoveFordward(uint_16 bValue){
	TPM0->CONTROLS[2].CnV = bValue;
	TPM0->CONTROLS[3].CnV = bValue;

}
void vfnMoveLeft(uint_16 bValue){

	TPM0->CONTROLS[2].CnV = bValue;
	TPM0->CONTROLS[1].CnV = bValue;
}
void vfnMoveRight(uint_16 bValue){
	TPM0->CONTROLS[0].CnV = bValue;
	TPM0->CONTROLS[3].CnV = bValue;
}
void vfnMoveBack(uint_16 bValue){
	TPM0->CONTROLS[0].CnV = bValue;
	TPM0->CONTROLS[1].CnV = bValue;

}
//PORTD0-CH0-RSF
////PORTD1-CH1-LSF
//PORTD2-CH2-RSB
//PORTD3-CH3-LSB
void vfnMoveFordAndRight(uint_16 bValue){
	TPM0->CONTROLS[3].CnV = bValue;
	TPM0->CONTROLS[2].CnV = (bValue*.3);
}
void vfnMoveFordAndLeft(uint_16 bValue){
	TPM0->CONTROLS[2].CnV = bValue;
	TPM0->CONTROLS[3].CnV = (bValue*.3);

}
void vfnMoveBackAndLeft(uint_16 bValue){
	TPM0->CONTROLS[0].CnV = bValue;
	TPM0->CONTROLS[1].CnV = (bValue*.3);
}
void vfnMoveBackAndRight(uint_16 bValue){
	TPM0->CONTROLS[1].CnV = bValue;
	TPM0->CONTROLS[0].CnV = (bValue*.3);

}
void vfnStopPWM(void){
	TPM0->CONTROLS[0].CnV = 0;
	TPM0->CONTROLS[1].CnV = 0;
	TPM0->CONTROLS[2].CnV = 0;
	TPM0->CONTROLS[3].CnV = 0;
__NOP();
}
