/*
 * PITDriver.h
 *
 *  Created on: 22 ago. 2020
 *      Author: user
 */

#ifndef HIL_PITDRIVER_H_
#define HIL_PITDRIVER_H_
#define PIT_IRQ PIT_DriverIRQHandler ///<To enter to the interrupcion
#include "MyTypes.h"
/**
 *CallBack
 *param[in]*(vfncall)(void)
 *
 */
void vfnPITCallBackreg(void *(vfncall)(void));
/**
 *Interruption
 */
void PIT_IRQ(void);
/**
 *PIT Driver init
 */
void vfnPITDriverInit(void);
/**
 *PIT enable
 *when you call this function, the PIT start counting
 */
void vfnPITEnable(void);
/**
 *PIT enable
 *when you call this function, the PIT stop counting
 */
void vfnPITDisable(void);
/**
 *PIT CheckFlag
 *Check the Timer Interrupt Flag
 *param[out]bStatus
 */
uint_8 bfnPITCheckFlag(void);



#endif /* HIL_PITDRIVER_H_ */
