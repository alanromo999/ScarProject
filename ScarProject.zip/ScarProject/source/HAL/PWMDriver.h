/*
 * PWMDriver.h
 *
 *  Created on: 17 ago. 2020
 *      Author: user
 */

#ifndef HIL_PWMDRIVER_H_
#define HIL_PWMDRIVER_H_
#include "MyTypes.h"
/**
 *Driver init
 */
void vfPWMDriverInit(void);
/**
 *Move the car fordward
 *param[in]bValue
 */
void vfnMoveFordward(uint_16 bValue);
/**
 *Move the 2 motors of right to the front and the 2 motors of left back
 *param[in]bValue
 */
void vfnMoveLeft(uint_16 bValue);
/**
 *Move the 2 motors of left to the front and the 2 motors of right back
 *param[in]bValue
 */
void vfnMoveRight(uint_16 bValue);
/**
 *Move the car back
 *param[in]bValue
 */
void vfnMoveBack(uint_16 bValue);
/**
 *Move the 2 motors of left to the front and the 2 motors of right to the front without 70%
 *param[in]bValue
 */
void vfnMoveFordAndRight(uint_16 bValue);
/**
 *Move the 2 motors of right to the front and the 2 motors of left to the front without 70%
 *param[in]bValue
 */
void vfnMoveFordAndLeft(uint_16 bValue);
/**
 *Move the 2 motors of right to the back and the 2 motors of left to the back without 70%
 *param[in]bValue
 */
void vfnMoveBackAndLeft(uint_16 bValue);
/**
 *Move the 2 motors of left to the back and the 2 motors of right to the back without 70%
 *param[in]bValue
 */
void vfnMoveBackAndRight(uint_16 bValue);
/**
 *Stop All the motors
 */
void vfnStopPWM(void);
#endif /* HIL_PWMDRIVER_H_ */
