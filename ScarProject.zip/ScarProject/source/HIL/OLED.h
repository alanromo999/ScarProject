/*
 * OLED.h
 *
 *  Created on: 19 jul. 2020
 *      Author: user
 */

#ifndef HIL_OLED_H_
#define HIL_OLED_H_
#include <HIL/Comunication.h>
#include "IIC_Driver.h"
#include "ADC.h"

//////////////////////////////////////////////////
#define SSD1306_HEIGHT        7   ///< OLED Command
#define SSD1306_WIDTH         127 ///< OLED Command

#define SSD1306_COMMAND                     0x00 ///< OLED Command
#define	SSD1306_DATA			            0xC0///< OLED Command
#define	SSD1306_DATA_CONTINUE		        0x40///< OLED Command

#define SSD1306_SET_CONTRAST_CONTROL		0x81///< OLED Command
#define	SSD1306_DISPLAY_ALL_ON_RESUME		0xA4///< OLED Command
#define	SSD1306_DISPLAY_ALL_ON       		0xA5///< OLED Command
#define	SSD1306_NORMAL_DISPLAY				0xA6///< OLED Command
#define	SSD1306_INVERT_DISPLAY				0xA7///< OLED Command
#define SSD1306_DISPLAY_OFF                 0xAE///< OLED Command
#define SSD1306_DISPLAY_ON                  0xAF///< OLED Command
#define SSD1306_NOP                         0xE3///< OLED Command
#define SSD1306_RESET                       0x7F///< OLED Command

#define	SSD1306_HORIZONTAL_SCROLL_RIGHT		0x26///< OLED Command
#define	SSD1306_HORIZONTAL_SCROLL_LEFT		0x27///< OLED Command
#define	SSD1306_HORIZONTAL_SCROLL_VERTICAL_AND_RIGHT		0x29///< OLED Command
#define	SSD1306_HORIZONTAL_SCROLL_VERTICAL_AND_LEFT    0x2A///< OLED Command
#define	SSD1306_DESACTIVATE_SCROLL    0x2E///< OLED Command
#define	SSD1306_ACTIVE_SCROLL         0x2F///< OLED Command
#define	SSD1306_SET_VERTICAL_SCROLL_AREA    0xA3///< OLED Command

#define	SSD1306_SET_LOWER_COLUMN 0x00///< OLED Command
#define	SSD1306_SET_HIGHER_COLUMN 0x10///< OLED Command
#define	SSD1306_MEMORY_ADDR_MODE 0x20///< OLED Command
#define	SSD1306_SET_COLUMN_ADDR 0x21///< OLED Command
#define	SSD1306_SET_PAGE_ADDR   0X22///< OLED Command

#define SSD1306_SET_START_LINE   0x40///< OLED Command
#define	SSD1306_SET_SEGMENT_REMAP	0xA0///< OLED Command
#define	SSD1306_SET_SEGMENT_REMAP_INV	0xA1///< OLED Command
#define SSD1306_SET_MULTIPLEX_RATIO   0xA8///< OLED Command
#define	SSD1306_COM_SCAN_DIR_INC			0xC0///< OLED Command
#define	SSD1306_COM_SCAN_DIR_DEC			0xC8///< OLED Command
#define SSD1306_SET_DISPLAY_OFFSET	  0xD3///< OLED Command
#define	SSD1306_SET_COM_PINS				0xDA///< OLED Command
#define	SSD1306_CHARGE_PUMP			0x8D///< OLED Command
#define	SSD1306_CHARGE_PUMP_ON				0x14///< OLED Command
#define	SSD1306_CHARGE_PUMP_OFF				 0x10///< OLED Command

#define	SSD1306_SET_DISPLAY_CLOCK_DIV_RATIO   0xD5///< OLED Command
#define SSD1306_SET_PRECHARGE_PERIOD          0x22///< OLED Command
#define	SSD1306_SET_VCOM_DESELECT             0x20///< OLED Command


///////////////////////////////////////////////////////////////////////
/**
*Print the OLED PAIRED
*/
void vfnPaired(void);
/**
*Print the battery on the oled
*/
void vfnsSSD1306CBat(void);
/**
*Send 8bits via i2c
*/
void vfnSSD1306_SendCommand(uint_8 Command);
/**
*Send 8bits via i2c
*/
void vfnSSD1306_SendData(void);
/**
*Send start comunication 12c
*/
void vfnSSD1306_SendStart(void);
/**
*Send stop comunication 12c
*/
void vfnSSD1306_SendStop(void);
/**
*Print char on the OLED
*@param[in] bch
*/
void vfnSSD1306_DisplayChar(uint_8 bch);
/**
*Print string on the OLED
*@param[in] ptr
*@param[in] Size
*/
void vfnSSD1306_DisplayString(uint_8 *ptr,uint_8 Size);
/**
*SD1306 Device init
*/
void vfnSSD1306_DeviceInit(void);
/**
*Delay
*/
void vfnDelay(void);
/**
*Print the image of the project
*/
void vfnSSD1306FirstImage(void);
/**
*Calls the ADC to check the stated of the battery
*/
uint_8 vfnSSD1306Batt(void);
/**
*Send 8bits via i2c
*/
void vfnSendData(void);
#endif /* HIL_OLED_H_ */
