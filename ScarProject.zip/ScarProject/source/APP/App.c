
//@file main.c
#include <GPIO.h>
#include <HIL/Comunication.h>
#include "OLED.h"
#include "PWMDriver.h"
#include "BTDriver.h"
#include "ADC.h"
#include "ScarDriver.h"
#undef SSDEXTERN ///< Preprocessor directives
/**
 * Main entry point of the program.
 */
int main(void) {
    COMM_vfnDriverInitAll();//INIT ALL DRIVER COMUN.
    vfPWMDriverInit();
    vfnADCDriverInit();//mal arquitectura, llamar a hil para llamar hal
    vfnGPIODriverInit();
#ifdef SSDEXTERN
    vfnSSD1306_DeviceInit();
    vfnSSD1306FirstImage();
#endif


    while(1){

    	vfnReadScarDataBT();
    }
    return 0;
}






