/*
 * LedDriver.h
 *
 *  Created on: 23 ago. 2020
 *      Author: user
 */

#ifndef HAL_GPIO_H_
#define HAL_GPIO_H_
#include "MyTypes.h"
/**
*Init GPIO
*/
void vfnGPIODriverInit(void);
/**
*Turn on the front leds
*/
void vfnLedTurnFOn(void);
/**
*Turn off the front leds
*/
void vfnLedTurnFOff(void);
/**
*Turn on the back leds
*/
void vfnLedTurnBOn(void);
/**
*Turn off the back leds
*/
void vfnLedTurnBOff(void);
#endif /* HAL_GPIO_H_ */
