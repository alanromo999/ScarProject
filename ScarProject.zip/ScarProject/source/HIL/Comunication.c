/*
 * Comunication.c
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#include <HIL/Comunication.h>

uint_8 (*CommSendGen[2])(uint_8 bData2Send) ={
		UART_bfnSend,
		I2C_bfnSend
};
uint_8 (*CommRecGen[2])(uint_8 *bData2Read) ={
		UART_bfnRead,
		I2C_bfnRead
};
uint_8 (*CommDriInit[2])(void)={
		UART_vfnDriverInit,
		I2C_bfnDriverInit
};
void COMM_vfnDriverInitAll(void){
COMM_vfnDriverInit(eUART_DRIVERINIT);
COMM_vfnDriverInit(eI2C_DRIVERINIT);
}
uint_8 COMM_vfnDriverInit (uint_8 bDriverInit){
	uint_8 bStatus=ERROR;
	if((*CommDriInit[bDriverInit])()){
		bStatus=SUCCESS;
	}else{
		bStatus=ERROR;
	}
	return bStatus;
}
//regresar que protocolos se inicializaron y si ya se inicializaron//*---
uint_8 COMM_bfnSendMsg (uint_8 * bpMsgToSend, uint_16 bMsgSize, uint_8 bProtocol){
	uint_8 bStatus=0;

	if((bpMsgToSend != NULL) && (bMsgSize)){
		if((bProtocol >= eUART_PROTOCOL) && (bProtocol <= eI2C_PROTOCOL)){
			while(bMsgSize){
				if((*CommSendGen[bProtocol])(* bpMsgToSend)){
					bMsgSize--;
					bpMsgToSend++;
				}else{

				}
			}
		}

	}//fin de if null
	return bStatus;
	}


uint_8 COMM_bfnReceiveMsg (	uint_8  *bpDataRx,uint_8 bProtocol){
	uint_8 bStatus=0;
	if(bpDataRx != NULL){
			if((bProtocol >= eUART_PROTOCOL) && (bProtocol <= eI2C_PROTOCOL)){
				while(bpDataRx){
					if((*CommRecGen[bProtocol])(bpDataRx)){
						if(*bpDataRx=='\n'){
							break;
						}
						bpDataRx++;

					}else{
                      //DO NOTHING
					}
				}
			}
	}
	return bStatus;
	}
