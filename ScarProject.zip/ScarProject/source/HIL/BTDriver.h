/*
 * BTDriver.h
 *
 *  Created on: 10 jul. 2020
 *      Author: user
 */

#ifndef HIL_BTDRIVER_H_
#define HIL_BTDRIVER_H_
#include <HIL/Comunication.h>

#define ENTER 13  ///< Value of Array
#define TALL 6 ///< Value of Array
#define LONG 16 ///< Value of Array
#define RECEIVE 20 ///< Value of Array
/**
 * Init of BTDriver
 * * @param[in] bProtocol
 */
void COMM_vfnBTComunication(uint_8 bProtocol);
/**
 * Read Recive Data
 */
void vfnReadDataBT(void);

#endif /* HIL_BTDRIVER_H_ */
