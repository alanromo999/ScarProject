/*
 * Comunication.h
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#ifndef HIL_COMUNICATION_H_
#define HIL_COMUNICATION_H_
#include <MyTypes.h>
#include <HAL/UART_Drive.h>
#include "IIC_Driver.h"

 typedef enum{
	 eUART_DRIVERINIT, ///< enum value
	 eI2C_DRIVERINIT ///< enum value
 }Driverinit;
	typedef enum{
		eUART_PROTOCOL, ///< enum value
		eI2C_PROTOCOL ///< enum value
	}Protocols;
	/**
* Comunication driver init
* Recive the protocol
* @param[in] bDriverInit
* @param[out] bStatus
*/
uint_8 COMM_vfnDriverInit (uint_8 bDriverInit);
/**
* Send Msg via a protocol
* @param[in] bProtocol
* @param[in] bMsgSize
* @param[in] bpMsgToSend
* @param[out] bStatus
*/
uint_8 COMM_bfnSendMsg (uint_8 * bpMsgToSend, uint_16 bMsgSize, uint_8 bProtocol);
/**
* Send Msg via a protocol
* @param[in] bProtocol
* @param[in] bpDataRx
* @param[out] bStatus
*/
uint_8 COMM_bfnReceiveMsg (	uint_8 *bpDataRx, uint_8 bProtocol);
/**
*Init all comunication protocol
*/
void COMM_vfnDriverInitAll(void);


#endif /* HIL_COMUNICATION_H_ */
