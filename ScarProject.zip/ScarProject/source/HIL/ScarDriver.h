/*
 * ScarDriver.h
 *
 *  Created on: 21 ago. 2020
 *      Author: user
 */

#ifndef HIL_SCARDRIVER_H_
#define HIL_SCARDRIVER_H_
#include "MyTypes.h"
#undef SSDEXTERN    ///< Preprocessor directives
/**
*State machine, we read the data of the app and do what we have to do
*/
void vfnReadScarDataBT(void);





#endif /* HIL_SCARDRIVER_H_ */
