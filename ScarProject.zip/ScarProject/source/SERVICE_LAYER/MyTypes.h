/*
 * SERVICE.h
 *
 *  Created on: 14 jun. 2020
 *      Author: user
 */

#ifndef SERVICE_LAYER_MYTYPES_H_
#define SERVICE_LAYER_MYTYPES_H_
#include "MKL27Z644.h"

	typedef unsigned char 			uint_8; ///< Variable type
	typedef unsigned short 			uint_16;///< Variable type
	typedef unsigned long 			uint_32;///< Variable type

	typedef signed char   			int_8;///< Variable type
	typedef signed short  			int_16;///< Variable type
	typedef signed long   			int_32;///< Variable type
    #define         TRUE            1 ///< Variable value
    #define         FALSE           0///< Variable value
	#define         SUCCESS			1///< Variable value
	#define         ERROR			0///< Variable value
	#define			ALTERNATIVA 	4///< Variable value
	#define			NULL			(void*)0///< null pointer


#endif /* SERVICE_LAYER_MYTYPES_H_ */
