/*
 * BTDriver.c
 *
 *  Created on: 10 jul. 2020
 *      Author: user
 */
#include <HiL/BTDriver.h>





void COMM_vfnBTComunication(uint_8 bProtocol)
{
    uint_8 bdata[14];
    uint_8 bRECEIVE[RECEIVE];
    uint_8 vArrayBid[TALL][RECEIVE];
    uint_8 bSize=0;
    uint_8 bTemp=0;
    uint_8 uartATC[3][15]={
                                {4,'A','T', '\r','\n'},
								{14,'A','T', '+', 'N', 'A', 'M', 'E', '=','S','C','A','R', '\r','\n' },//cambiar nombre
								{14,'A','T','+','P','S','W','D','=','0','0','0','0', '\r','\n'},
								{12,'A','T', '+', 'R', 'O', 'L', 'E', '=','0', '\r', '\n' },//iniciar comunicacion
								{11,'A','T', '+', 'U', 'A', 'R', 'T', '?', '\r', '\n'}//iniciar comunicacion
								//{13,'A','T', '+', 'V', 'E', 'R', 'S', 'I', 'O', 'N', '?', '\r', '\n' }//VERSION
	};



    for (uint_8 cont = 0; cont<3; cont++)
    {
        for(uint_8 bRange=0;bRange<15;bRange++)
        {
            if(bRange==0){
                bSize=uartATC[cont][bRange];
                bRange++;
		 	}//fin del if
                bdata[bRange-1]=uartATC[cont][bRange];
        }//fin del segundo for
        for(uint_8 clean=0;clean<RECEIVE;clean++){
        	bRECEIVE[clean]=0;
        }
            COMM_bfnSendMsg (&bdata[0],bSize,eUART_PROTOCOL);
            COMM_bfnReceiveMsg (&bRECEIVE[0],eUART_PROTOCOL);
                for(uint_8 i=0;i<RECEIVE;i++)
                {
                    vArrayBid[bTemp][i]=bRECEIVE[i];
                }
                   bTemp++;
    }//fin del primer for
__NOP();
}
